> 包内适配版(mygamestudio 0.7.0,任务票 02)。来源:插件设计仓库 `.scratch/mygamestudio-framework/contracts/design.md`。本版仅把指向未随包设计文档的链接改为文字引用,语义与设计一致;文件指纹与来源见包内 `provenance/manifest.md`。

# 设计技能合同

运行任一入口前采用[共同合同](common.md)。本组默认由方案设计承担。

## Game-Design

- 输入:本轮问题、当前产品要求、相关反馈、资源与投入约束。
- 工作:处理玩法、数值和体验讨论。局部问题复用公开技能 `grilling` 与 `domain-modeling`，按已具备前提的问题成组提问。三句话说明核心玩法后围绕最小闭环深入。专业模块按真实影响读取。大型不清晰路线提示开发者调用 `wayfinder`，不自动串调。读取[阶段资料入口](../game/stage-requirements.md)不是开始制作。
- 输出:候选方案、取舍、需要验证的问题、试验数值与用户已作出的决定。
- 写入:本轮设计过程和决定记录，不把未采纳提议或试验值写入正式规则；明确采纳的内容由开发者主动调用 `to-spec` 同步整体入口及按需模块。
- 完成:本轮问题得到决定或形成明确验证工作,剩余问题有去向;助手建议不冒充用户决定。无显式请求不增加隔离原型，不安排外部玩家。

## Game-Spec

- 输入:已经讨论并采纳的决定、当前游戏设计、必要技术约定、原型及验证引用。
- 工作:整理本轮目标、范围、行为、约束和完成标准;更新当前产品设计及需要的局部规格。技术设计由制作实现维护,本入口引用其约定。
- 输出:适用的游戏设计变更、可执行规格及基线版本。
- 写入:产品设计基线和相关规格;未采纳的选项保存为讨论或明确待定。
- 完成:准备执行的内容有明确要求和验收依据;目标变化已经过对应同步。已有内容足够时以引用交接。

## Game-Prototype

- 输入:要验证的设计问题、当前约定、原型范围、可用工具和输出位置。
- 工作:选择最小可检验实现,按需要复用编码、素材和运行能力;原型工作保持方案设计的用途和资源范围。
- 输出:隔离原型、运行或查看方式、实验与试玩记录、结论和未决事项。
- 写入:获准的原型区、设计验证记录;正式工程集成归制作实现。
- 完成:目标问题有实际证据或明确说明验证受限;原型可运行不等于正式产品已经实现。

三项技能按需求组合。已经明确的设计可以直接进入规格整理;当前问题不需要原型时不强制增加原型步骤。

## 包内说明

当前包的有效设计入口是 Game-Design。`to-spec` / `prototype` 为 Matt 公开技能,不再作为游戏侧独立入口。设计讨论与现行规格维护的公开接缝是 `records/mgs_records.py` 的 `read_current_design`、`plan_design_discussion`、`apply_design_discussion`、`plan_spec_adoption`、`apply_spec_adoption`。正式版本设计快照的公开接缝是同一文件的 `plan_design_snapshot`、`apply_design_snapshot`、`read_design_snapshots`：另存归档,不改写现行正文。可玩任务拆分与交付的公开接缝是同一文件的 `plan_playable_delivery`、`apply_playable_delivery`、`record_playable_result`。本地 Markdown 旧项目完整资料迁移的公开接缝是同一文件的 `plan_local_material_migration`、`apply_local_material_migration`、`read_local_material_migration`：转换后的设计可被现行规格与快照接缝读取,成果待切换,不改现行指针。本地 Markdown 以整体设计文件与追加历史为现行来源;GitHub Issues 以规格 Issue 正文与评论为现行来源。每项目只维护一种 tracker。普通工作不经 mgs-gate。
