# 管理技能合同

> 包内适配版(mygamestudio 0.1.0,任务票 01)。来源:插件设计仓库 `.scratch/mygamestudio-framework/contracts/management.md`。本版仅把指向未随包设计文档的链接改为文字引用,语义与设计一致;文件指纹与来源见包内 `provenance/manifest.md`。

运行任一入口前采用[共同合同](common.md)。本组默认由制作统筹承担,专业产物通过对应角色完成。

## Game-Producer

- 输入:用户需求、当前项目约定、相关基线、任务与已有结果。
- 工作:只读查询目标、进展、缺口与建议;按[调用合同](../game/invocation.md)做按需路由。不自动串调 Matt 用户专用入口。Game-Status 职责并入本入口。
- 输出:当前状态、缺口、建议下一步和管理记录(仅在已授权写入时)。
- 写入:状态查询只读。管理记录仅在已授权时更新。专业文档与代码由其责任角色修改。
- 完成:本次请求已交付,或阻塞及下一步明确;每项状态与事实对应。读取资料不等于已开始制作。

## Game-Init

- 输入:明确的目标项目与接入请求;已有项目的代码、资源、文档及配置。
- 工作:分析已有游戏并补齐必要游戏接入资料,包括指向[阶段资料入口](../game/stage-requirements.md)的短指针。通用 tracker、标签与领域文档配置交给 `setup-matt-pocock-skills`。
- 输出:现状与缺口、资料映射、具体变更清单、实际应用结果和剩余事项。
- 写入:原项目分析阶段只读;确认后按清单写入。配置与权限动作单独说明范围,不扩大授权。
- 完成:清单中已执行事项有结果;未做的通用 setup 不标为完成。

## Game-Plan

- 输入:当前工作目标、已采纳规格、适用技术约定和已有任务。
- 工作:组织专业角色提出拆解,形成当前及近期的原子任务,核对真实依赖和修改重叠;按[分流规则](task-triage.md)安排。
- 输出:逐项任务、交付与完成标准、执行和验收责任、依赖及基线引用。
- 写入:任务请求、整体计划和分流记录;需求及技术约定通过引用保持原维护者。
- 完成:准备执行的任务输入与依赖清楚;缺信息、需要人或不再安排的事项可区分。

## Game-Status

并入 Game-Producer 的只读查询。本文件保留本节仅作旧入口去向说明,不是独立公开技能。

---

包内说明(issue #50/#51/#57/#58):有效管理入口为 Game-Producer 与 Game-Init。Game-Plan 通用职责交给 `to-tickets`;Game-Status 并入 Game-Producer。本地 Markdown 接入、任务维护与只读状态查询由接入票实现;已有本地 Markdown 项目的完整资料转换由 `records/mgs_records.py` 的 `plan_local_material_migration` / `apply_local_material_migration` / `read_local_material_migration` 完成,GitHub 旧项目由 `plan_github_material_migration` / `apply_github_material_migration` / `read_github_material_migration` 完成,成果待切换,不改现行指针。普通工作不经 mgs-gate。
